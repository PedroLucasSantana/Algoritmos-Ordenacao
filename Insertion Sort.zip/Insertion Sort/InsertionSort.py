def insertionsort(lista):
    for q in range(1, len(lista)):
        chave = lista[q]
        c = q - 1
        while c >= 0 and lista[c] > chave:
            lista[c + 1] = lista[c]
            c -= 1
        lista[c + 1] = chave

numeros = [7, 2, 4, 1, 5]
print("Antes de ordenar:", numeros)
insertionsort(numeros)
print("Depois de ordenar:", numeros)
