#Vantagens: Ele é ótimo para quem está aprendendo lógica de programação e algoritomos, usando poucas linhas de codigo com uma logica direta de dois for e uma comparação
# Funciona mto bem em lista pequenas entre 3 a 10 elementos, funcina bem e nao da problemas e pode ser otimizado caso a lista ja estiver ordenada.
# Desvantegens: Muito lendo com listas grandes, ele acaba comparando elementos e comparando com o selection sort ele faz muitas mais trocas, oq pode ser prejudicial
# se o custo da troca for muito alto, e em situações reais como programas sistemas e banco de dados não é uma boa opção outros algoritimos acabando sendo opções melhores.

def bubblesort(lista):
    n = len(lista)
    for a in range(n):
        for g in range(0, n - a - 1):
            if lista[g] > lista[g + 1]:
                lista[g], lista[g + 1] = lista[g + 1], lista[g]

numeros = [7, 2, 5, 3, 1]

print("Antes de ordenar:", numeros)
bubblesort(numeros)
print("Depois de ordenar:", numeros)
