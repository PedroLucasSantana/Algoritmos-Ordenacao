def selectionsort(lista):
    for i in range(len(lista)):
        menor = i
        for j in range(i + 1, len(lista)):
            if lista[j] < lista[menor]:
                menor = j
        # Troca os valores
        lista[i], lista[menor] = lista[menor], lista[i]

# Exemplo de uso:
numeros = [5, 3, 8, 4, 2]
print("Antes:", numeros)
selectionsort(numeros)
print("Depois:", numeros)
